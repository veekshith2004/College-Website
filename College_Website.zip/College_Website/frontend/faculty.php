<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['role'])) {
    header("Location: login.html");
    exit();
}

// Ensure user has faculty role
if ($_SESSION['role'] !== 'faculty') {
    header("Location: unauthorized.html"); // Redirect non-faculty users
    exit();
}

// Example faculty courses (Replace with database retrieval)
$courses = ["Mathematics", "Physics", "Computer Science", "English Literature"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Panel</title>
    
    <style>
        /* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    display: flex;
    height: 100vh;
    background-color: #f4f4f4;
}

/* Sidebar */
.sidebar {
    width: 250px;
    background-color: #2c3e50;
    color: white;
    padding: 20px;
    position: fixed;
    height: 100%;
    overflow-y: auto;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
}

.sidebar ul {
    list-style: none;
    padding: 0;
}

.sidebar ul li {
    margin: 15px 0;
}

.sidebar ul li a {
    color: black;
    text-decoration: none;
    font-size: 16px;
    display: block;
    padding: 10px;
    border-radius: 5px;
    transition: 0.3s;
}

.sidebar ul li a:hover {
    background-color: #34495e;
}

/* Main Content */
.main-content {
    margin-left: 250px;
    flex-grow: 1;
    padding: 40px;
}

h1 {
    font-size: 28px;
    color: #333;
}

h2 {
    font-size: 22px;
    margin-top: 20px;
    color: #555;
}

/* Courses List */
ul {
    list-style: none;
    margin-top: 10px;
}

ul li {
    background: white;
    padding: 12px;
    margin: 5px 0;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: 0.3s;
}

ul li:hover {
    background-color: #ecf0f1;
}

/* Responsive Design */
@media (max-width: 768px) {
    .sidebar {
        width: 200px;
    }
    
    .main-content {
        margin-left: 200px;
        padding: 20px;
    }
}

@media (max-width: 500px) {
    body {
        flex-direction: column;
    }
    
    .sidebar {
        width: 100%;
        height: auto;
        position: relative;
    }
    
    .main-content {
        margin-left: 0;
        padding: 20px;
    }
}

    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Faculty Panel</h2>
        <ul>
            <li><a href="#">Dashboard</a></li>
            <li><a href="courses.php">Manage Courses</a></li>
            <li><a href="notes.php">Add notes</a></li>
            <li><a href="faculty_profile.php">Profile</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h1>Welcome, Faculty</h1>
        <h2>Your Courses</h2>
        <ul>
            <?php foreach ($courses as $course): ?>
                <li><?php echo htmlspecialchars($course); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    
    
</body>
</html>
