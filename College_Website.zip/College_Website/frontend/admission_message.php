<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to database
$conn = new mysqli("localhost", "root", "", "user_db");

if ($conn->connect_error) {
    die("❌ Connection Failed: " . $conn->connect_error);
}

// Handle Delete Request
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Prepare and execute delete query
    $stmt = $conn->prepare("DELETE FROM admission WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo "<script>alert('✅ Admission record deleted successfully!'); window.location.href='admin.php';</script>";
    } else {
        echo "<script>alert('❌ Error deleting record.');</script>";
    }
    $stmt->close();
}

// Fetch All Admission Records
$result = $conn->query("SELECT * FROM admission ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Admissions</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">📋 Admission Records</h2>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Course</th>
                <th>Student Name</th>
                <th>Parent Name</th>
                <th>Parent Occupation</th>
                <th>Address</th>
                <th>Student Mobile</th>
                <th>Parent Mobile</th>
                <th>College</th>
                <th>Percentage</th>
                <th>Hostel</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['course']; ?></td>
                    <td><?= $row['studentName']; ?></td>
                    <td><?= $row['parentName']; ?></td>
                    <td><?= $row['parentOccupation']; ?></td>
                    <td><?= $row['address']; ?></td>
                    <td><?= $row['studentMobile']; ?></td>
                    <td><?= $row['parentMobile']; ?></td>
                    <td><?= $row['college']; ?></td>
                    <td><?= $row['percentage']; ?>%</td>
                    <td><?= $row['hostel']; ?></td>
                    <td>
                        <a href="admin.php?delete=<?= $row['id']; ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Are you sure you want to delete this record?');">
                            Delete
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
