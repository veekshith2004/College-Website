<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Include the database connection
include('db_connect.php');

// Initialize variables for storing form data
$name = $email = $department = $profile_picture = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $department = $_POST['department'];

    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        // Check if the uploaded file is an image (for example, jpeg or png)
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['profile_picture']['type'];

        if (in_array($file_type, $allowed_types)) {
            // Save the profile picture in the 'uploads' directory
            $profile_picture = 'uploads/' . basename($_FILES['profile_picture']['name']);
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $profile_picture)) {
                echo "File uploaded successfully!";
            } else {
                echo "Error uploading file!";
            }
        } else {
            echo "Invalid file type! Only JPG, PNG, or GIF images are allowed.";
        }
    } else {
        $profile_picture = NULL; // No profile picture uploaded
    }

    // Insert the faculty profile data into the database
    if ($name && $email && $department) {
        $query = "INSERT INTO faculty_profiles (name, email, department, profile_picture) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssss", $name, $email, $department, $profile_picture);
        $stmt->execute();
    }

    // Reload the page after inserting the data
    header("Location: faculty_profile.php"); // Refresh the page to show the inserted data
    exit();
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Delete the profile from the database
    $query = "DELETE FROM faculty_profiles WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        // Optionally, delete the profile picture file
        $result = $conn->query("SELECT profile_picture FROM faculty_profiles WHERE id = $delete_id");
        $row = $result->fetch_assoc();
        if ($row && $row['profile_picture']) {
            unlink($row['profile_picture']); // Delete the file
        }

        // Redirect back to the profile page after deletion
        header("Location: faculty_profile.php");
        exit();
    } else {
        echo "Error deleting profile!";
    }
}

// Fetch the faculty profiles to display them
$query = "SELECT * FROM faculty_profiles";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Profile</title>
    <link rel="stylesheet" href="faculty_profile.css"> <!-- Link to your external CSS file -->
</head>
<body>

<div class="container">
    <h1>Create Faculty Profile</h1>

    <!-- Faculty Profile Form -->
    <form action="faculty_profile.php" method="POST" enctype="multipart/form-data">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required><br>

        <label for="department">Department:</label>
        <input type="text" id="department" name="department" value="<?php echo htmlspecialchars($department); ?>" required><br>

        <label for="profile_picture">Profile Picture:</label>
        <input type="file" id="profile_picture" name="profile_picture"><br>

        <button type="submit">Create Profile</button>
    </form>

    <h2>Faculty Profiles</h2>

    <!-- Display Faculty Profiles -->
    <?php while ($faculty = $result->fetch_assoc()): ?>
        <div class="profile">
            <div class="profile-id">ID: <?php echo htmlspecialchars($faculty['id']); ?></div>
            <div class="profile-info">
                <h3><?php echo htmlspecialchars($faculty['name']); ?></h3>
                <p>Email: <?php echo htmlspecialchars($faculty['email']); ?></p>
                <p>Department: <?php echo htmlspecialchars($faculty['department']); ?></p>
                <p>
                    <?php if ($faculty['profile_picture']): ?>
                        <img src="<?php echo htmlspecialchars($faculty['profile_picture']); ?>" alt="Profile Picture" width="100">
                    <?php else: ?>
                        <img src="default-profile.jpg" alt="Profile Picture" width="100">
                    <?php endif; ?>
                </p>
            </div>
            <!-- Delete button -->
            <a href="faculty_profile.php?delete_id=<?php echo $faculty['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this profile?')">Delete</a>
        </div>
    <?php endwhile; ?>
</div>

</body>
</html>
