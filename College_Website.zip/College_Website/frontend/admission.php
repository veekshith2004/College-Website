<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to database
$conn = new mysqli("localhost", "root", "", "user_db");

if ($conn->connect_error) {
    die("❌ Connection Failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    // Get form data
    $course = $_POST["course"];
    $studentName = $_POST["studentName"];
    $parentName = $_POST["parentName"];
    $parentOccupation = $_POST["parentOccupation"];
    $address = $_POST["address"];
    $studentMobile = $_POST["studentMobile"];
    $parentMobile = $_POST["parentMobile"];
    $college = $_POST["college"];
    $percentage = $_POST["percentage"];
    $hostel = $_POST["hostel"];

    // SQL Query
    $sql = "INSERT INTO admission (course, studentName, parentName, parentOccupation, address, studentMobile, parentMobile, college, percentage, hostel) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("❌ SQL Error: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("ssssssssds", $course, $studentName, $parentName, $parentOccupation, $address, $studentMobile, $parentMobile, $college, $percentage, $hostel);

    // Execute query
    if ($stmt->execute()) {
        echo "<script>alert('✅ Admission Submitted Successfully!'); window.location.href='amai.html';</script>";
    } else {
        echo "❌ Execution Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
