<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$database = "user_db";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete
if (isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    $conn->query("DELETE FROM announcements WHERE id = $delete_id");
    echo "<script>alert('Announcement deleted successfully!'); window.location.href='announcements.php';</script>";
    exit;
}

// Handle new announcement
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_announcement'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];

    $stmt = $conn->prepare("INSERT INTO announcements (title, content, created_at) VALUES (?, ?, NOW())");
    $stmt->bind_param("ss", $title, $content);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Announcement added successfully!'); window.location.href='announcements.php';</script>";
    exit;
}

// Fetch announcements
$result_admin = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
$result_public = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Announcements</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Manage Announcements (Admin Panel)</h2>
    <form method="POST" class="mb-4">
        <input type="text" name="title" class="form-control mb-2" placeholder="Title" required>
        <textarea name="content" class="form-control mb-2" placeholder="Content" required></textarea>
        <button type="submit" name="add_announcement" class="btn btn-primary">Add Announcement</button>
    </form>

    <h3>All Announcements (Admin View)</h3>
    <ul class="list-group mb-5">
        <?php while ($row = $result_admin->fetch_assoc()): ?>
            <li class="list-group-item">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <strong><?= $row['title']; ?></strong>
                        <p><?= $row['content']; ?></p>
                        <small><?= $row['created_at']; ?></small>
                    </div>
                    <a href="announcements.php?delete=<?= $row['id']; ?>" 
                       class="btn btn-danger btn-sm ms-3"
                       onclick="return confirm('Are you sure you want to delete this announcement?');">
                        Delete
                    </a>
                </div>
            </li>
        <?php endwhile; ?>
    </ul>

    <hr>

    <h2 class="mt-5">Latest Announcements (Public View)</h2>
    <ul class="list-group">
        <?php while ($row = $result_public->fetch_assoc()): ?>
            <li class="list-group-item text-center">
                <strong><?= $row['title']; ?></strong>
                <p><?= $row['content']; ?></p>
                <small><?= $row['created_at']; ?></small>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

</body>
</html>

<?php $conn->close(); ?>
