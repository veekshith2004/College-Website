<?php
include 'db_connect.php'; // Ensure this connects to your database

$sql = "SELECT * FROM course"; 
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courses</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f9fa;
        }
        .course-section {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
            justify-content: center;
        }
        .course-card {
            width: 280px;
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease-in-out;
        }
        .course-card:hover {
            transform: scale(1.05);
        }
        .course-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
        }
        .course-card h5 {
            font-weight: bold;
            margin: 10px 0 5px;
            font-size: 18px;
        }
        .course-card p {
            margin: 5px 0;
            font-size: 16px;
            color: #555;
        }
        .category-title {
            font-size: 20px;
            font-weight: bold;
            margin: 20px 0;
            text-align: left;
            padding-left: 10px;
        }
    </style>
</head>
<body>

<h2 class="category-title">Under Graduate</h2>
<div class="course-section">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Check if image exists, fallback to default
            $imagePath = !empty($row['image']) ? 'uploads/' . $row['image'] : 'default.jpg';

            echo '
            <div class="course-card">
                <img src="' . htmlspecialchars($imagePath) . '" alt="' . htmlspecialchars($row["course_name"]) . '" onerror="this.src=\'default.jpg\';">
                <h5>' . htmlspecialchars($row["course_name"]) . '</h5>
                <p>Duration – ' . htmlspecialchars($row["duration"]) . ' Years</p>
            </div>';
        }
    } else {
        echo "<p>No courses available</p>";
    }
    $conn->close();
    ?>
</div>

</body>
</html>
