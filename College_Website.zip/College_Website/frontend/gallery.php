<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// DB Connection
$conn = new mysqli("localhost", "root", "", "user_db");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Upload Image
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["image"])) {
    $dir = "uploads/gallery/";
    if (!is_dir($dir)) mkdir($dir, 0777, true);

    $file = $dir . basename($_FILES["image"]["name"]);
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $allowed = ["jpg", "jpeg", "png", "gif"];

    if (!in_array($ext, $allowed)) {
        echo "<script>alert('Only JPG, PNG, GIF allowed');</script>";
    } elseif (move_uploaded_file($_FILES["image"]["tmp_name"], $file)) {
        $stmt = $conn->prepare("INSERT INTO gallery (image_url, uploaded_at) VALUES (?, NOW())");
        $stmt->bind_param("s", $file);
        $stmt->execute();
        $stmt->close();
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "<script>alert('Upload failed');</script>";
    }
}

// Delete Image
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("SELECT image_url FROM gallery WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($img);
    $stmt->fetch();
    $stmt->close();
    if (file_exists($img)) unlink($img);

    $stmt = $conn->prepare("DELETE FROM gallery WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

$result = $conn->query("SELECT * FROM gallery ORDER BY uploaded_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Gallery Upload</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f9f9f9; }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: 0.3s;
        }
        .card:hover { transform: scale(1.02); }
        .card img {
            height: 200px;
            object-fit: cover;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }
    </style>
</head>
<body>
<div class="container py-5">
    <h2 class="text-center mb-4">📸 Upload Gallery Image</h2>

    <form action="" method="POST" enctype="multipart/form-data" class="d-flex justify-content-center mb-5">
        <input type="file" name="image" class="form-control w-50 me-2" required>
        <button type="submit" class="btn btn-primary">Upload</button>
    </form>

    <h3 class="text-center mb-4">🖼️ Your Gallery</h3>
    <div class="row justify-content-center">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="card text-center">
                    <img src="<?= $row['image_url']; ?>" alt="Image">
                    <div class="card-body">
                        <h5 class="card-title">Uploaded Image</h5>
                        <p class="card-text text-muted"><?= $row['uploaded_at']; ?></p>
                        <a href="?delete=<?= $row['id']; ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Delete this image?');">Delete</a>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
</body>
</html>

<?php $conn->close(); ?>
