<?php
include 'db_connect.php';

$query = "SELECT * FROM notes ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
$notes = mysqli_fetch_all($result, MYSQLI_ASSOC);

echo json_encode($notes);
?>
