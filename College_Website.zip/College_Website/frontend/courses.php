<?php
$host = "localhost";
$username = "root"; 
$password = "";
$database = "user_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Delete Request
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];

    // Get image name to delete the file
    $stmt = $conn->prepare("SELECT image FROM course WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->bind_result($imageToDelete);
    $stmt->fetch();
    $stmt->close();

    // Delete image file if it exists
    if ($imageToDelete && file_exists("uploads/$imageToDelete")) {
        unlink("uploads/$imageToDelete");
    }

    // Delete course from DB
    $stmt = $conn->prepare("DELETE FROM course WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        echo "<script>alert('Course deleted successfully!'); window.location.href='courses.php';</script>";
    } else {
        echo "<script>alert('Error deleting course: " . $stmt->error . "');</script>";
    }
    $stmt->close();
}

// Handle Add Course Form Submission
if (isset($_POST['add_course'])) {
    $course_name = $_POST['course_name'];
    $description = $_POST['description'];
    $duration = $_POST['duration'];

    // Handle Image Upload
    $image = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $image_path = "uploads/" . basename($image);

    if (!is_dir('uploads')) {
        mkdir('uploads', 0777, true);
    }

    if (move_uploaded_file($image_tmp, $image_path)) {
        $query = "INSERT INTO course (course_name, description, duration, image) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssis", $course_name, $description, $duration, $image);

        if ($stmt->execute()) {
            echo "<script>alert('Course added successfully!'); window.location.href='courses.php';</script>";
        } else {
            echo "<script>alert('Error adding course: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Error uploading image!');</script>";
    }
}

// Fetch All Courses
$result = $conn->query("SELECT * FROM course");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Courses</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">Manage Courses</h2>

    <form method="POST" enctype="multipart/form-data" class="mb-3">
        <div class="row">
            <div class="col-md-3">
                <input type="text" name="course_name" class="form-control" placeholder="Course Name" required>
            </div>
            <div class="col-md-3">
                <input type="text" name="description" class="form-control" placeholder="Description" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="duration" class="form-control" placeholder="Duration (Years)" required>
            </div>
            <div class="col-md-3">
                <input type="file" name="image" class="form-control" accept="image/*" required>
            </div>
            <div class="col-md-1">
                <button type="submit" name="add_course" class="btn btn-primary">Add</button>
            </div>
        </div>
    </form>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Course Name</th>
                <th>Description</th>
                <th>Duration (Years)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td>
                        <img src="uploads/<?= !empty($row['image']) ? $row['image'] : 'default.jpg'; ?>" 
                             alt="<?= $row['course_name']; ?>" width="80" height="80" 
                             style="border-radius: 5px; object-fit: cover;">
                    </td>
                    <td><?= $row['course_name']; ?></td>
                    <td><?= $row['description']; ?></td>
                    <td><?= $row['duration']; ?></td>
                    <td>
                        <a href="courses.php?delete=<?= $row['id']; ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Are you sure you want to delete this course?');">
                            Delete
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</div>

</body>
</html>

<?php $conn->close(); ?>
