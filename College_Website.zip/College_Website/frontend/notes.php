<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'faculty') {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $rating = mysqli_real_escape_string($conn, $_POST['rating']);
    
    $file_name = $_FILES['file']['name'];
    $file_tmp = $_FILES['file']['tmp_name'];
    $file_path = "uploads/" . basename($file_name);
    
    if (!empty($title) && !empty($author) && !empty($rating) && !empty($file_name)) {
        if (move_uploaded_file($file_tmp, $file_path)) {
            $query = "INSERT INTO notes (faculty_username, title, author, file_path, rating, created_at) 
                      VALUES ('{$_SESSION['username']}', '$title', '$author', '$file_path', '$rating', NOW())";
            
            if (mysqli_query($conn, $query)) {
                echo "<script>alert('Note uploaded successfully!');</script>";
            } else {
                echo "<script>alert('Error uploading note.');</script>";
            }
        } else {
            echo "<script>alert('File upload failed.');</script>";
        }
    }
}

// Fetch notes added by faculty
$query = "SELECT * FROM notes WHERE faculty_username = '{$_SESSION['username']}' ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
$notes = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Notes</title>
    <style>
        /* General Styling */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background: #2c3e50;
            padding: 20px;
            position: fixed;
            left: 0;
            top: 0;
            color: white;
        }

        .sidebar h2 {
            text-align: center;
            font-size: 22px;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 10px 0;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: 0.3s;
        }

        .sidebar ul li a:hover {
            background: #34495e;
        }

        /* Main Content */
        .main-content {
            margin-left: 270px;
            padding: 20px;
        }

        h1, h2 {
            color: #2c3e50;
        }

        /* Upload Form */
        form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 500px;
        }

        input, button {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #3498db;
            color: white;
            border: none;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background-color: #2980b9;
        }

        /* Notes List */
        ul {
            list-style: none;
            padding: 0;
        }

        li {
            background: white;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .download-link {
            color: #27ae60;
            font-weight: bold;
            text-decoration: none;
            transition: 0.3s;
        }

        .download-link:hover {
            color: #2ecc71;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Faculty Panel</h2>
        <ul>
            <li><a href="faculty.php">Back to Faculty Panel</a></li>
        </ul>
    </div>
    
    <div class="main-content">
        <h1>Upload Notes</h1>
        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="title" placeholder="Enter Notes Title" required><br>
            <input type="text" name="author" placeholder="Enter Author Name" required><br>
            <input type="file" name="file" required><br>
            <input type="number" name="rating" min="1" max="5" placeholder="Rate (1-5)" required><br>
            <button type="submit">Upload Note</button>
        </form>

        <h2>Your Uploaded Notes</h2>
        <ul>
            <?php foreach ($notes as $note): ?>
                <li>
                    <strong><?php echo htmlspecialchars($note['title']); ?></strong> by 
                    <?php echo htmlspecialchars($note['author']); ?> - 
                    Rating: <?php echo htmlspecialchars($note['rating']); ?>/5 
                    <a href="<?php echo htmlspecialchars($note['file_path']); ?>" download>Download</a>
                    <small>(<?php echo $note['created_at']; ?>)</small>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>
