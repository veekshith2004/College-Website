<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: user_dashboard.php");
    exit();
}

if (!isset($_SESSION['user_role'])) {
    header("Location: login.php");
    exit();
}

// Role-based access control
if ($_SESSION['user_role'] !== 'admin') {
    header("Location: user_dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - College Website</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            margin: 0;
            background: #f4f4f4;
        }
        .sidebar {
            width: 250px;
            background: #081c54;
            color: white;
            padding-top: 20px;
            position: fixed;
            height: 100%;
            overflow: auto;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            padding: 15px;
            text-align: center;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
        }
        .sidebar ul li a:hover {
            background: #f3c623;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
        }
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        .card h3 {
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="users.php">Manage Users</a></li>
            <li><a href="courses.php">Manage Courses</a></li>
            <li><a href="announcements.php">Announcements</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="messages.php">Contact Messages</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.html">Logout</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h1>Welcome, Admin</h1>
        <p>Manage the college website efficiently.</p>
        <div class="dashboard-cards">
            <div class="card">
                <h3>Total Students</h3>
                <p>200+</p>
            </div>
            <div class="card">
                <h3>Total Faculty</h3>
                <p>50+</p>
            </div>
            <div class="card">
                <h3>Active Courses</h3>
                <p>10+</p>
            </div>
            <div class="card">
                <h3>Pending Inquiries</h3>
                <p>5</p>
            </div>
        </div>
    </div>
</body>
</html>
