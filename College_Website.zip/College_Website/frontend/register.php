<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encrypt password

    // Ensure 'role' exists and is not empty
    if (!isset($_POST['role']) || empty($_POST['role'])) {
        die("Error: Role selection is required. Please go back and choose a role.");
    }

    $role = trim($_POST['role']); // Get role value

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $email, $password, $role);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! You can now log in.'); window.location.href='login.html';</script>";
    } else {
        echo "<script>alert('Error occurred. Try again!'); window.location.href='register.html';</script>";
    }
    $stmt->close();
}
?>
