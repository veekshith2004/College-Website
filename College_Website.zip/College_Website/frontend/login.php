<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $userType = $_POST['userType']; // Get user selection

    if (empty($username) || empty($password) || empty($userType)) {
        echo "<script>alert('All fields are required!'); window.location.href='login.html';</script>";
        exit();
    }

    $sql = "SELECT * FROM users WHERE username = '$username' AND role = '$userType'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $user['role'];

            // Redirect based on role
            if ($user['role'] == 'admin') {
                header("Location: admin.html"); // Admin panel
                exit();
            } elseif ($user['role'] == 'faculty') {
                header("Location: faculty.php"); // Faculty panel
                exit();
            } else {
                header("Location: amai.html"); // Student panel
                exit();
            }
        } else {
            echo "<script>alert('Incorrect password!'); window.location.href='login.html';</script>";
            exit();
        }
    } else {
        echo "<script>alert('User not found or role mismatch!'); window.location.href='register.html';</script>";
        exit();
    }
}
?>
