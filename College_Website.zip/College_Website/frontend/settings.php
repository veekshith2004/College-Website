<?php
session_start();
if (!isset($_SESSION['user_role'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include('sidebar.php'); ?>
    <div class="main-content">
        <h1>Settings</h1>
        <p>Settings page under construction.</p>
    </div>
</body>
</html>
